<script name="Copyright" setup></script>

<template>
  <el-space spacer="|">
    <span>{{ $t('system.copyright') }}</span>
    <span>{{ $t('system.icp') }}</span>
  </el-space>
</template>

<style scoped>
.copyright {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
</style>
