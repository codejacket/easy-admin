<script name="404" setup></script>

<template>
  <div>404</div>
</template>

<i18n src="./locales/en.json" locale="en" />
<i18n src="./locales/zh-CN.json" locale="zh-CN" />
