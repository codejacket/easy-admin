import { addCollection } from '@iconify/vue'
import collections from 'virtual:local-iconify'

collections.forEach(addCollection)
